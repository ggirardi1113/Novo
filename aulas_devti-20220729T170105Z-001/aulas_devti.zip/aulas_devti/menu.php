<nav class="navbar navbar-expand-lg bg-light">
    <a href="?pagina=produtos_lista" class="btn btn-info">Lista de Produtos</a>
    <a href="?pagina=produtos_cadastro" class="btn btn-success">Cadastro de Produtos</a>
</nav>
<hr>