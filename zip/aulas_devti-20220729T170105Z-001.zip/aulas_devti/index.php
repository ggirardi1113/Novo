<?php
    session_start();

    include_once('lib/conexao.php');
    include_once('lib/sql.php');