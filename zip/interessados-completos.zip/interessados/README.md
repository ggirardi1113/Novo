# interessados

Esse código mostra o uso de Ajax + JQuery + PHP para realizar um cadastro de Interessados em um NewsLetter.
Exemplo para o Curso DEVs-TI - UNIDAVI
