<?php
    $arrey="1|2|3|4|5|6";
    $mostra=explode('|',$arrey);
    for ($i=0; $i < 6; $i++) { 
        echo $mostra[$i],'<br>';
    }
?>