<a href="?">Home</a>
<br>
<a href="?pagina=explode">explode</a>
<br>