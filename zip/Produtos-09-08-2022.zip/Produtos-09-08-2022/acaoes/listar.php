<h1>Listagem</h1>
<nav class="navbar navbar-expand-lg bg-light">
    <a href="?pagina=listar&listar=fornecedores" class="btn btn-info">Fornecedores</a>
    <a href="?pagina=listar&listar=produtos" class="btn btn-success">Produtos</a>
</nav>