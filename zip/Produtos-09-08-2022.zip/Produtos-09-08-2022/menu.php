<nav class="navbar navbar-expand-lg bg-light">
    <a href="?pagina=listar" class="btn btn-info">Lista</a>
    <a href="?pagina=produtos_cadastro" class="btn btn-success">Cadastro de Produtos</a>
</nav>
<hr>