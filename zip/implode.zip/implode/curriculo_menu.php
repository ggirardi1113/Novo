<a href="?">Home</a>
<br>
<a href="?pagina=implode">Implode</a>
<br>