<?php
    $arrey=array(1,2,3,4,5);
    $mostra=implode('|',$arrey);
    echo $mostra;
?>